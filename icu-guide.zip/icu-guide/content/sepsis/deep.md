## Definition
Sepsis is life-threatening organ dysfunction caused by infection.

## Treatment
1. Stabilize airway
2. Fluids
3. Vasopressors
