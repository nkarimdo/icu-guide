## Recognition
- Infection + organ dysfunction
- Lactate elevation

## Immediate actions
- Cultures
- Antibiotics
- IV fluids
